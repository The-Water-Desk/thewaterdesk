<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',            "http://demo_content.tagdiv.com/Newspaper_6/blog_coffee/logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_other',             "http://demo_content.tagdiv.com/Newspaper_6/blog_coffee/logo-other.png");


// other images
td_demo_media::add_image_to_media_gallery('aboutme',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_coffee/aboutme.jpg");