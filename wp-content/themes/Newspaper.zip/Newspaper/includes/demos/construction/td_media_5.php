<?php

td_demo_media::add_image_to_media_gallery('contact-hero',            "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_contact-hero_xxx.jpg");
td_demo_media::add_image_to_media_gallery('dots',                    "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_dots_xxx.png");
td_demo_media::add_image_to_media_gallery('experience',              "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_experience_xxx.jpg");
td_demo_media::add_image_to_media_gallery('img4',                    "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_img4_xxx.jpg");
td_demo_media::add_image_to_media_gallery('services-hero',           "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_services-hero_xxx.jpg");
td_demo_media::add_image_to_media_gallery('tools',                   "http://demo_content.tagdiv.com/Newspaper_multi/construction/xxx_tools_xxx.jpg");
