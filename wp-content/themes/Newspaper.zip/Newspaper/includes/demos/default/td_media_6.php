<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/default_8/p3.jpg");
//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo',                'http://demo_content.tagdiv.com/Newspaper_6/default_9/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_mobile',         'http://demo_content.tagdiv.com/Newspaper_6/default_9/logo-mobile.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newspaper_6/default_9/logo-footer.png');
//ads
td_demo_media::add_image_to_media_gallery('td_default_ad_full',         "http://demo_content.tagdiv.com/Newspaper_6/default_8/newspaper-rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_default_ad_sidebar',      "http://demo_content.tagdiv.com/Newspaper_6/default_9/newspaper-rec300.jpg");