<?php

// ads
td_demo_media::add_image_to_media_gallery('td_influencer_reclama',                          "http://demo_content.tagdiv.com/Newspaper_6/influencer/reclama.jpg");
td_demo_media::add_image_to_media_gallery('td_influencer_reclama_retina',                   "http://demo_content.tagdiv.com/Newspaper_6/influencer/reclama-retina.jpg");

//newsletter background
td_demo_media::add_image_to_media_gallery('td_pic_newsletter',                              "http://demo_content.tagdiv.com/Newspaper_6/influencer/newsletter.jpg");

//search background
td_demo_media::add_image_to_media_gallery('td_pic_search',                                  "http://demo_content.tagdiv.com/Newspaper_6/influencer/search.jpg");