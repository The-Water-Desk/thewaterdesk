<?php

//404 image
td_demo_media::add_image_to_media_gallery('td_pic_404',                                     "http://demo_content.tagdiv.com/Newspaper_6/influencer/404.jpg");

//author bg image
td_demo_media::add_image_to_media_gallery('td_pic_author_bg',                               "http://demo_content.tagdiv.com/Newspaper_6/influencer/author-bg.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_about',                                   "http://demo_content.tagdiv.com/Newspaper_6/influencer/about.jpg");