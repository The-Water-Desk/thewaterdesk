<?php
/**
 * Created by ra on 5/14/2015.
 */

// featured images
td_demo_media::add_image_to_media_gallery('td_pic_1',                   "http://demo_content.tagdiv.com/Newspaper_6/decor/1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_2',                   "http://demo_content.tagdiv.com/Newspaper_6/decor/2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_3',                   "http://demo_content.tagdiv.com/Newspaper_6/decor/3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_4',                   "http://demo_content.tagdiv.com/Newspaper_6/decor/4.jpg");