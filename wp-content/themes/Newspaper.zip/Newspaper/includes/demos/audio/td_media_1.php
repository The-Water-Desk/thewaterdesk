<?php
/**
 * Created by ra on 5/14/2015.
 */

// post images
td_demo_media::add_image_to_media_gallery('td_p1',                           "http://demo_content.tagdiv.com/Newspaper_6/video_pro/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_p2',                           "http://demo_content.tagdiv.com/Newspaper_6/video_pro/p2.jpg");

// ads
td_demo_media::add_image_to_media_gallery('td_custom_rec',                   "http://demo_content.tagdiv.com/Newspaper_6/video_pro/custom-rec.jpg");
td_demo_media::add_image_to_media_gallery('td_custom_rec_mob',               "http://demo_content.tagdiv.com/Newspaper_6/video_pro/custom-rec-mobile.jpg");



