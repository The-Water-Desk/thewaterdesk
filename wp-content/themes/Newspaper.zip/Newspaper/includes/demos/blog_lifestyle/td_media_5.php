<?php

td_demo_media::add_image_to_media_gallery('td_pic_header_image',              "http://demo_content.tagdiv.com/Newspaper_6/blog_lifestyle/header-image.png");
td_demo_media::add_image_to_media_gallery('td_pic_header_bg',                 "http://demo_content.tagdiv.com/Newspaper_6/blog_lifestyle/header-bg.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_author_image',              "http://demo_content.tagdiv.com/Newspaper_6/blog_lifestyle/author-image.jpg");
